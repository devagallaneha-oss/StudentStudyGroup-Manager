@echo off
cd /d "%~dp0"
if exist out rmdir /s /q out
mkdir out\web
javac -d out src\studygroup\*.java test\studygroup\*.java || exit /b 1
copy /y src\web\index.html out\web\index.html >nul
echo Build OK -> out
