#!/usr/bin/env bash
# Builds and starts the dashboard. Usage: ./run.sh [port]
cd "$(dirname "$0")"
./build.sh && java -cp out studygroup.Main "${1:-8080}"
