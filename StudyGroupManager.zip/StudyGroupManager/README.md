# Student Study Group Management (Java + Role-Based Dashboards)

Pure Java (JDK 11+), **no external libraries**. A built-in HTTP server
(`com.sun.net.httpserver`) serves role-aware dashboards and a small REST API.

## Run
Linux / macOS:  `./run.sh`            Windows:  `run.bat`
Then open **http://localhost:8080**  (custom port: `./run.sh 9000`).
Only a JDK (11+) is needed - **no Maven**.

Run the tests: `./test.sh` (Windows: `test.bat`)

## Sign in (demo accounts)
| Username | Password | Role | Can do |
|----------|----------|------|--------|
| `admin` | `admin123` | Admin | Create groups, view members, remove members |
| `drrao`, `profmehta` | `faculty123` | Faculty | Create groups, view members, remove members |
| `asha`, `vikram` | `cr123` | Student CR | Create groups, join / leave |
| `ravi`, `meena`, `kiran`, `sana`, `divya`, `arjun`, `neha`, `rohit`, `isha`, `karan`, `tara`, `dev`, `lata`, `priya` | `student123` | Student | Join / leave (Create Group is locked) |

Permissions are enforced on the **server** (HTTP 401 not signed in, 403 not allowed),
so they cannot be bypassed by calling the API directly. See `Role.java`.

## Dashboards (tabs)
| Tab | What it shows |
|-----|---------------|
| Overview | Your permissions, KPI tiles, occupancy bars, members-by-subject donut, live activity feed |
| Join Group | KPIs, "where is there room" bar chart, search/subject/hide-full filters, group cards with a seat map; Join button disabled when full / already joined / not a student |
| Leave Group | Your groups with your seat highlighted, confirm dialog, your activity. Faculty/Admin see **Remove Members** instead |
| View Members | Group picker with mini bars, occupancy gauge, seat map, student/CR role mix, members table incl. "also in" other groups |
| Create Group | **Student CR, Faculty, Admin only** - form with live preview. Plain students see a locked page |

## Requirements -> where they are implemented
| # | Requirement | Code |
|---|-------------|------|
| 1 | Groups: name, subject, description | `GroupService.createGroup` (role-checked) |
| 2 | Join / leave | `GroupService.join / leave` |
| 3 | Display members | `Group.getMembers`, View Members dashboard |
| 4 | Maximum capacity | `Group.capacity`, validated 1-100 |
| 5 | Reject join when full | `GroupFullException` (HTTP 409) |
| + | Search by name/subject | `GroupService.search` |
| + | Roles & login | `Role`, `User`, `AuthService` |

## REST API (send `Authorization: Bearer <token>` except for login)
| Method | Path | Body (form-encoded) | Who |
|--------|------|---------------------|-----|
| POST | `/api/login` | `username, password` | anyone |
| GET  | `/api/me`, POST `/api/logout` | | signed in |
| GET  | `/api/groups?q=&available=true` | | signed in |
| POST | `/api/groups` | `name, subject, description, capacity` | CR, Faculty, Admin |
| GET  | `/api/groups/{id}` | | signed in |
| POST | `/api/groups/{id}/join` | (you join as yourself) | Student, CR |
| POST | `/api/groups/{id}/leave` | `student` (optional; someone else = remove) | self: Student/CR; others: Faculty, Admin |
| GET  | `/api/stats`, `/api/activity` | | signed in |

## Structure
```
src/studygroup/  Role, User, AuthService, Group, GroupService, Activity, GroupFullException,
                 StudyGroupException, Json, SeedData, DashboardServer, Main
src/web/index.html   login + all dashboards (HTML + CSS + JS, works offline)
test/studygroup/ServiceTests.java   service rules + real HTTP 401/403 checks
```
Data is kept in memory (resets on restart); demo users and groups are loaded by `SeedData`.
Passwords are stored as salted hashes. This is demo-grade auth (no HTTPS, in-memory sessions).
