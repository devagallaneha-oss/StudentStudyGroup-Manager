package studygroup;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

/** Dependency-free tests: the 5 functional requirements, search, and role permissions. Run: ./test.sh */
public class ServiceTests {
    static int passed = 0, failed = 0;

    static void check(String name, boolean ok) {
        if (ok) { passed++; System.out.println("  PASS  " + name); }
        else    { failed++; System.out.println("  FAIL  " + name); }
    }

    static boolean throwsFull(Runnable r) {
        try { r.run(); return false; } catch (GroupFullException e) { return true; }
    }

    static boolean throwsAny(Runnable r) {
        try { r.run(); return false; } catch (StudyGroupException e) { return true; }
    }

    static boolean throwsStatus(int status, Runnable r) {
        try { r.run(); return false; } catch (StudyGroupException e) { return e.getStatus() == status; }
    }

    public static void main(String[] args) throws Exception {
        AuthService auth = new AuthService();
        User admin = auth.register("admin", "Admin", Role.ADMIN, "pw");
        User prof = auth.register("prof", "Prof", Role.FACULTY, "pw");
        User cr = auth.register("cr", "Cathy", Role.CR, "pw");
        User asha = auth.register("asha", "Asha", Role.STUDENT, "pw");
        User ravi = auth.register("ravi", "Ravi", Role.STUDENT, "pw");
        User meena = auth.register("meena", "Meena", Role.STUDENT, "pw");
        User kiran = auth.register("kiran", "Kiran", Role.STUDENT, "pw");
        GroupService s = new GroupService();

        System.out.println("0. Who may create groups");
        check("student cannot create (403)", throwsStatus(403, () -> s.createGroup(asha, "Nope", "x", "", 3)));
        Group g = s.createGroup(cr, "Algo Club", "Computer Science", "Algorithms", 2);
        check("student CR can create", g.getCreatedBy().equals("Cathy"));
        check("faculty can create", s.createGroup(prof, "Prof Group", "Physics", "", 4) != null);
        check("admin can create", s.createGroup(admin, "Admin Group", "Maths", "", 4) != null);

        System.out.println("1. Groups");
        check("group created with name/subject/description", g.getName().equals("Algo Club")
                && g.getSubject().equals("Computer Science") && g.getDescription().equals("Algorithms"));
        check("blank name rejected", throwsAny(() -> s.createGroup(cr, " ", "x", "", 3)));
        check("duplicate name rejected", throwsAny(() -> s.createGroup(cr, "algo club", "x", "", 3)));

        System.out.println("2. Membership");
        s.join(asha, g.getId());
        check("student joined", s.get(g.getId()).hasMember("Asha"));
        check("duplicate join rejected", throwsAny(() -> s.join(asha, g.getId())));
        s.leave(asha, g.getId(), null);
        check("student left", !s.get(g.getId()).hasMember("Asha"));
        check("leaving when not a member rejected", throwsAny(() -> s.leave(asha, g.getId(), null)));
        check("faculty cannot join (403)", throwsStatus(403, () -> s.join(prof, g.getId())));
        check("admin cannot join (403)", throwsStatus(403, () -> s.join(admin, g.getId())));

        System.out.println("3. Members");
        s.join(ravi, g.getId());
        check("members listed", s.getMembers(g.getId()).equals(java.util.List.of("Ravi")));
        check("student cannot remove another member (403)", throwsStatus(403, () -> s.leave(asha, g.getId(), "Ravi")));
        check("member still there", s.get(g.getId()).hasMember("Ravi"));

        System.out.println("4. Capacity");
        check("capacity stored", g.getCapacity() == 2);
        check("capacity 0 rejected", throwsAny(() -> s.createGroup(cr, "Bad", "x", "", 0)));

        System.out.println("5. Full groups");
        s.join(meena, g.getId());
        check("group is full", s.get(g.getId()).isFull());
        check("join to full group rejected", throwsFull(() -> s.join(kiran, g.getId())));
        s.leave(prof, g.getId(), "Ravi");
        check("faculty can remove a member", !s.get(g.getId()).hasMember("Ravi"));
        s.join(kiran, g.getId());
        check("seat freed after removal can be reused", s.get(g.getId()).hasMember("Kiran"));
        s.leave(admin, g.getId(), "Kiran");
        check("admin can remove a member", !s.get(g.getId()).hasMember("Kiran"));

        System.out.println("Optional: search + activity");
        check("search by name", s.search("algo", false).size() == 1);
        check("search by subject", s.search("computer", false).size() == 1);
        check("activity feed records events", !s.recentActivity(5).isEmpty()
                && s.recentActivity(1).get(0).type.equals("removed"));

        System.out.println("Login");
        check("wrong password rejected (401)", throwsStatus(401, () -> auth.login("asha", "bad")));
        check("unknown user rejected (401)", throwsStatus(401, () -> auth.login("ghost", "pw")));
        String t = auth.login("ASHA", "pw");
        check("login returns working token", auth.require(t).getName().equals("Asha"));
        auth.logout(t);
        check("token invalid after logout", throwsStatus(401, () -> auth.require(t)));

        httpTests();

        System.out.println("\n" + passed + " passed, " + failed + " failed");
        if (failed > 0) System.exit(1);
    }

    /** End-to-end: real HTTP server, real requests. Proves the rules cannot be bypassed from the browser. */
    static void httpTests() throws Exception {
        System.out.println("HTTP API");
        AuthService auth = new AuthService();
        GroupService svc = new GroupService();
        SeedData.load(auth, svc);
        DashboardServer server = new DashboardServer(svc, auth, 0);
        server.start();
        int port = server.getPort();
        HttpClient http = HttpClient.newHttpClient();
        String base = "http://localhost:" + port;
        try {
            check("no token -> 401", call(http, base, "GET", "/api/groups", null, null) == 401);
            check("bad login -> 401", call(http, base, "POST", "/api/login", null, "username=asha&password=x") == 401);
            String student = tokenOf(http, base, "ravi", "student123");
            String cr = tokenOf(http, base, "asha", "cr123");
            String fac = tokenOf(http, base, "drrao", "faculty123");
            String adm = tokenOf(http, base, "admin", "admin123");
            String form = "name=HttpGroup&subject=Art&description=d&capacity=3";
            check("student POST /api/groups -> 403", call(http, base, "POST", "/api/groups", student, form) == 403);
            check("CR POST /api/groups -> 201", call(http, base, "POST", "/api/groups", cr, form) == 201);
            check("faculty POST /api/groups -> 201", call(http, base, "POST", "/api/groups", fac,
                    "name=HttpGroup2&subject=Art&description=d&capacity=3") == 201);
            check("admin POST /api/groups -> 201", call(http, base, "POST", "/api/groups", adm,
                    "name=HttpGroup3&subject=Art&description=d&capacity=3") == 201);
            check("student join -> 200", call(http, base, "POST", "/api/groups/2/join", student, "") == 200 ||
                    call(http, base, "POST", "/api/groups/2/join", student, "") == 409);
            check("faculty join -> 403", call(http, base, "POST", "/api/groups/2/join", fac, "") == 403);
            check("join full group -> 409", call(http, base, "POST", "/api/groups/1/join", tokenOf(http, base, "priya", "student123"), "") == 409);
            check("student removing others -> 403", call(http, base, "POST", "/api/groups/1/leave", student, "student=Asha") == 403);
            check("admin removing a member -> 200", call(http, base, "POST", "/api/groups/1/leave", adm, "student=Kiran") == 200);
        } finally {
            server.stop();
        }
    }

    static String tokenOf(HttpClient http, String base, String u, String p) throws Exception {
        HttpResponse<String> r = http.send(HttpRequest.newBuilder(URI.create(base + "/api/login"))
                .header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString("username=" + u + "&password=" + p)).build(),
                HttpResponse.BodyHandlers.ofString());
        String b = r.body();
        int i = b.indexOf("\"token\":\"") + 9;
        return b.substring(i, b.indexOf('"', i));
    }

    static int call(HttpClient http, String base, String method, String path, String token, String body) throws Exception {
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(base + path))
                .header("Content-Type", "application/x-www-form-urlencoded");
        if (token != null) b.header("Authorization", "Bearer " + token);
        b.method(method, body == null ? HttpRequest.BodyPublishers.noBody() : HttpRequest.BodyPublishers.ofString(body));
        return http.send(b.build(), HttpResponse.BodyHandlers.ofString()).statusCode();
    }
}
