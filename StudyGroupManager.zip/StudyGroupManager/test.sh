#!/usr/bin/env bash
cd "$(dirname "$0")"
./build.sh && java -cp out studygroup.ServiceTests
