package studygroup;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

/** An account. Passwords are stored as a salted SHA-256 hash, never in clear text. */
public final class User {
    private static final SecureRandom RANDOM = new SecureRandom();

    private final String username;
    private final String name;      // display name; this is what appears as a group member
    private final Role role;
    private final String salt;
    private final String hash;

    public User(String username, String name, Role role, String password) {
        this.username = username.trim().toLowerCase();
        this.name = name.trim();
        this.role = role;
        byte[] s = new byte[12];
        RANDOM.nextBytes(s);
        this.salt = hex(s);
        this.hash = hash(salt, password);
    }

    public String getUsername() { return username; }
    public String getName() { return name; }
    public Role getRole() { return role; }

    public boolean checkPassword(String password) {
        return password != null && MessageDigest.isEqual(
                hash.getBytes(StandardCharsets.UTF_8), hash(salt, password).getBytes(StandardCharsets.UTF_8));
    }

    private static String hash(String salt, String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return hex(md.digest((salt + ":" + password).getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    private static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x));
        return sb.toString();
    }
}
