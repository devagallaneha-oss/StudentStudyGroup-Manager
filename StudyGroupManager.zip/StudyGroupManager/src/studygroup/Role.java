package studygroup;

/** The four kinds of account and what each one is allowed to do. */
public enum Role {
    STUDENT("Student"),
    CR("Student CR"),
    FACULTY("Faculty"),
    ADMIN("Admin");

    private final String label;

    Role(String label) { this.label = label; }

    public String getLabel() { return label; }

    /** Create Group dashboard: Student CR, Faculty and Admin only (plain students are locked out). */
    public boolean canCreateGroups() { return this != STUDENT; }

    /** Join / leave for themselves: only students (including CRs). */
    public boolean canJoinGroups() { return this == STUDENT || this == CR; }

    /** Removing somebody else from a group: faculty and admin only. */
    public boolean canRemoveOthers() { return this == FACULTY || this == ADMIN; }
}
