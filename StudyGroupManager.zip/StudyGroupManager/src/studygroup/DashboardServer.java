package studygroup;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Embedded HTTP server (JDK built-in com.sun.net.httpserver).
 * Serves the dashboard page and a small REST API.
 */
public class DashboardServer {
    private final GroupService service;
    private final AuthService auth;
    private final HttpServer server;

    public DashboardServer(GroupService service, AuthService auth, int port) throws IOException {
        this.service = service;
        this.auth = auth;
        this.server = HttpServer.create(new InetSocketAddress(port), 0);
        this.server.createContext("/", this::handle);
    }

    public void start() { server.start(); }
    public int getPort() { return server.getAddress().getPort(); }
    public void stop() { server.stop(0); }

    private void handle(HttpExchange ex) throws IOException {
        try {
            String path = ex.getRequestURI().getPath();
            if (path.startsWith("/api/")) api(ex, path);
            else staticFile(ex, path);
        } catch (StudyGroupException e) {
            send(ex, e.getStatus(), "application/json", Json.error(e.getMessage()));
        } catch (NumberFormatException e) {
            send(ex, 400, "application/json", Json.error("Invalid number in request."));
        } catch (Exception e) {
            e.printStackTrace();
            send(ex, 500, "application/json", Json.error("Internal server error."));
        } finally {
            ex.close();
        }
    }

    // ---------------------------------------------------------------- API
    private void api(HttpExchange ex, String path) throws IOException {
        String method = ex.getRequestMethod();
        String[] p = path.substring(5).split("/"); // after "/api/"
        Map<String, String> query = parseForm(ex.getRequestURI().getRawQuery());

        // POST /api/login  (form: username, password)  -> user + token. The only public endpoint.
        if (p[0].equals("login") && method.equals("POST")) {
            Map<String, String> f = parseForm(readBody(ex));
            String token = auth.login(f.get("username"), f.get("password"));
            send(ex, 200, "application/json", Json.user(auth.require(token), token));
            return;
        }

        // everything below needs a signed-in user (Authorization: Bearer <token>)
        String token = bearer(ex);
        User user = auth.require(token);

        if (p[0].equals("me") && method.equals("GET")) {
            send(ex, 200, "application/json", Json.user(user, null));
            return;
        }
        if (p[0].equals("logout") && method.equals("POST")) {
            auth.logout(token);
            send(ex, 200, "application/json", "{\"ok\":true}");
            return;
        }
        if (p[0].equals("stats") && method.equals("GET")) {
            send(ex, 200, "application/json", stats());
            return;
        }
        if (p[0].equals("activity") && method.equals("GET")) {
            send(ex, 200, "application/json", Json.activity(service.recentActivity(12)));
            return;
        }
        if (!p[0].equals("groups")) {
            send(ex, 404, "application/json", Json.error("Unknown endpoint."));
            return;
        }

        // GET /api/groups?q=...&available=true
        if (p.length == 1 && method.equals("GET")) {
            boolean avail = "true".equalsIgnoreCase(query.get("available"));
            send(ex, 200, "application/json", Json.groups(service.search(query.get("q"), avail), auth::roleKeyOf));
            return;
        }
        // POST /api/groups  (form: name, subject, description, capacity)  -> CR / Faculty / Admin only
        if (p.length == 1 && method.equals("POST")) {
            Map<String, String> f = parseForm(readBody(ex));
            Group g = service.createGroup(user, f.get("name"), f.get("subject"), f.get("description"),
                    Integer.parseInt(f.getOrDefault("capacity", "0").trim()));
            send(ex, 201, "application/json", Json.group(g, auth::roleKeyOf));
            return;
        }
        int id = Integer.parseInt(p[1]);
        // GET /api/groups/{id}
        if (p.length == 2 && method.equals("GET")) {
            send(ex, 200, "application/json", Json.group(service.get(id), auth::roleKeyOf));
            return;
        }
        // POST /api/groups/{id}/join   (you join as yourself)
        // POST /api/groups/{id}/leave  (form: student = optional; naming someone else needs Faculty/Admin)
        if (p.length == 3 && method.equals("POST")) {
            if (p[2].equals("join")) {
                send(ex, 200, "application/json", Json.group(service.join(user, id), auth::roleKeyOf));
                return;
            }
            if (p[2].equals("leave")) {
                Map<String, String> f = parseForm(readBody(ex));
                send(ex, 200, "application/json", Json.group(service.leave(user, id, f.get("student")), auth::roleKeyOf));
                return;
            }
        }
        send(ex, 404, "application/json", Json.error("Unknown endpoint."));
    }

    private static String bearer(HttpExchange ex) {
        String h = ex.getRequestHeaders().getFirst("Authorization");
        return h != null && h.startsWith("Bearer ") ? h.substring(7).trim() : null;
    }

    private String stats() {
        List<Group> all = service.all();
        int members = 0, capacity = 0, full = 0;
        Map<String, int[]> bySubject = new LinkedHashMap<>(); // subject -> {groups, members}
        for (Group g : all) {
            members += g.getMemberCount();
            capacity += g.getCapacity();
            if (g.isFull()) full++;
            int[] a = bySubject.computeIfAbsent(g.getSubject(), k -> new int[2]);
            a[0]++;
            a[1] += g.getMemberCount();
        }
        StringBuilder sb = new StringBuilder("{");
        sb.append("\"totalGroups\":").append(all.size());
        sb.append(",\"totalMembers\":").append(members);
        sb.append(",\"totalCapacity\":").append(capacity);
        sb.append(",\"openSeats\":").append(capacity - members);
        sb.append(",\"fullGroups\":").append(full);
        sb.append(",\"bySubject\":[");
        boolean first = true;
        for (Map.Entry<String, int[]> e : bySubject.entrySet()) {
            if (!first) sb.append(',');
            first = false;
            sb.append("{\"subject\":").append(Json.str(e.getKey()))
              .append(",\"groups\":").append(e.getValue()[0])
              .append(",\"members\":").append(e.getValue()[1]).append('}');
        }
        return sb.append("]}").toString();
    }

    // ------------------------------------------------------------- static
    private void staticFile(HttpExchange ex, String path) throws IOException {
        if (path.equals("/") || path.equals("/index.html")) {
            try (InputStream in = DashboardServer.class.getResourceAsStream("/web/index.html")) {
                if (in == null) {
                    send(ex, 500, "text/plain", "web/index.html not found on classpath");
                    return;
                }
                send(ex, 200, "text/html; charset=utf-8", new String(in.readAllBytes(), StandardCharsets.UTF_8));
            }
        } else {
            send(ex, 404, "text/plain", "Not found");
        }
    }

    // ------------------------------------------------------------ helpers
    private static String readBody(HttpExchange ex) throws IOException {
        return new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
    }

    private static Map<String, String> parseForm(String s) {
        Map<String, String> m = new LinkedHashMap<>();
        if (s == null || s.isEmpty()) return m;
        for (String pair : s.split("&")) {
            int i = pair.indexOf('=');
            String k = i < 0 ? pair : pair.substring(0, i);
            String v = i < 0 ? "" : pair.substring(i + 1);
            m.put(URLDecoder.decode(k, StandardCharsets.UTF_8), URLDecoder.decode(v, StandardCharsets.UTF_8));
        }
        return m;
    }

    private static void send(HttpExchange ex, int status, String type, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", type.contains("json") ? "application/json; charset=utf-8" : type);
        ex.getResponseHeaders().set("Cache-Control", "no-store");
        ex.sendResponseHeaders(status, bytes.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(bytes);
        }
    }
}
