package studygroup;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * All business logic for study groups, including who is allowed to do what.
 * Thread-safe (methods are synchronized).
 */
public class GroupService {
    private static final int MAX_ACTIVITY = 30;

    private final Map<Integer, Group> groups = new LinkedHashMap<>();
    private final Deque<Activity> activity = new ArrayDeque<>();
    private int nextId = 1;

    /**
     * Create a group (name, subject, description, maximum capacity).
     * Only Student CR, Faculty and Admin may do this; plain students get a 403.
     */
    public synchronized Group createGroup(User actor, String name, String subject, String description, int capacity) {
        if (!actor.getRole().canCreateGroups())
            throw new StudyGroupException("Only Student CR, Faculty and Admin can create study groups.", 403);
        name = clean(name);
        subject = clean(subject);
        description = clean(description);
        if (name.isEmpty()) throw new StudyGroupException("Group name is required.", 400);
        if (subject.isEmpty()) throw new StudyGroupException("Subject is required.", 400);
        if (capacity < 1 || capacity > 100)
            throw new StudyGroupException("Capacity must be between 1 and 100.", 400);
        for (Group g : groups.values()) {
            if (g.getName().equalsIgnoreCase(name))
                throw new StudyGroupException("A group named \"" + name + "\" already exists.", 409);
        }
        Group g = new Group(nextId++, name, subject, description, capacity, actor.getName());
        groups.put(g.getId(), g);
        log("create", actor.getName(), g.getName(), actor.getName());
        return g;
    }

    /** Join a group as yourself; rejected when the group is at capacity. Students and CRs only. */
    public synchronized Group join(User actor, int groupId) {
        if (!actor.getRole().canJoinGroups())
            throw new StudyGroupException(actor.getRole().getLabel()
                    + " accounts cannot join groups. Students join; you can view and manage members.", 403);
        String student = actor.getName();
        Group g = find(groupId);
        if (g.hasMember(student))
            throw new StudyGroupException("You are already a member of \"" + g.getName() + "\".", 409);
        if (g.isFull()) throw new GroupFullException(g.getName(), g.getCapacity());
        g.addMember(student);
        log("join", student, g.getName(), student);
        return g;
    }

    /**
     * Leave a group. With a blank/own {@code target} the actor leaves; naming somebody else
     * removes that member and is only allowed for Faculty and Admin.
     */
    public synchronized Group leave(User actor, int groupId, String target) {
        target = clean(target);
        boolean self = target.isEmpty() || target.equalsIgnoreCase(actor.getName());
        if (self) target = actor.getName();
        else if (!actor.getRole().canRemoveOthers())
            throw new StudyGroupException("Only Faculty and Admin can remove other members.", 403);
        Group g = find(groupId);
        if (!g.removeMember(target))
            throw new StudyGroupException((self ? "You are" : target + " is") + " not a member of \"" + g.getName() + "\".", 404);
        log(self ? "leave" : "removed", target, g.getName(), actor.getName());
        return g;
    }

    /** Members of a group. */
    public synchronized List<String> getMembers(int groupId) {
        return new ArrayList<>(find(groupId).getMembers());
    }

    public synchronized Group get(int groupId) { return find(groupId); }

    /** Search by name/subject and/or only groups with free places. */
    public synchronized List<Group> search(String query, boolean availableOnly) {
        String q = query == null ? "" : query.trim().toLowerCase();
        List<Group> result = new ArrayList<>();
        for (Group g : groups.values()) {
            boolean matches = q.isEmpty()
                    || g.getName().toLowerCase().contains(q)
                    || g.getSubject().toLowerCase().contains(q);
            if (matches && (!availableOnly || !g.isFull())) result.add(g);
        }
        return result;
    }

    public synchronized List<Group> all() { return search("", false); }

    /** Newest first. */
    public synchronized List<Activity> recentActivity(int limit) {
        List<Activity> out = new ArrayList<>();
        for (Activity a : activity) {
            if (out.size() >= limit) break;
            out.add(a);
        }
        return out;
    }

    private void log(String type, String student, String group, String by) {
        activity.addFirst(new Activity(type, student, group, by));
        while (activity.size() > MAX_ACTIVITY) activity.removeLast();
    }

    private Group find(int id) {
        Group g = groups.get(id);
        if (g == null) throw new StudyGroupException("Group #" + id + " not found.", 404);
        return g;
    }

    private static String clean(String s) {
        return s == null ? "" : s.trim().replaceAll("\\s+", " ");
    }
}
