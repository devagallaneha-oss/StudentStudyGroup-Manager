package studygroup;

/** Base exception for all business-rule violations. Carries an HTTP-like status code. */
public class StudyGroupException extends RuntimeException {
    private final int status;

    public StudyGroupException(String message, int status) {
        super(message);
        this.status = status;
    }

    public int getStatus() {
        return status;
    }
}
