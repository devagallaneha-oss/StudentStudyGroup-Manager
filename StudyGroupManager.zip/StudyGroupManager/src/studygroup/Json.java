package studygroup;

import java.util.List;
import java.util.function.Function;

/** Tiny JSON writer so the project needs no external libraries. */
public final class Json {
    private Json() {}

    public static String str(String s) {
        StringBuilder sb = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
            }
        }
        return sb.append('"').toString();
    }

    /** @param roleOf maps a member's display name to their role key (STUDENT, CR, ...) */
    public static String group(Group g, Function<String, String> roleOf) {
        StringBuilder sb = new StringBuilder("{");
        sb.append("\"id\":").append(g.getId());
        sb.append(",\"name\":").append(str(g.getName()));
        sb.append(",\"subject\":").append(str(g.getSubject()));
        sb.append(",\"description\":").append(str(g.getDescription()));
        sb.append(",\"createdBy\":").append(str(g.getCreatedBy()));
        sb.append(",\"capacity\":").append(g.getCapacity());
        sb.append(",\"memberCount\":").append(g.getMemberCount());
        sb.append(",\"seatsLeft\":").append(g.getSeatsLeft());
        sb.append(",\"full\":").append(g.isFull());
        sb.append(",\"members\":[");
        List<String> m = g.getMembers();
        for (int i = 0; i < m.size(); i++) {
            if (i > 0) sb.append(',');
            sb.append("{\"name\":").append(str(m.get(i)))
              .append(",\"role\":").append(str(roleOf.apply(m.get(i)))).append('}');
        }
        return sb.append("]}").toString();
    }

    public static String groups(List<Group> list, Function<String, String> roleOf) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < list.size(); i++) {
            if (i > 0) sb.append(',');
            sb.append(group(list.get(i), roleOf));
        }
        return sb.append(']').toString();
    }

    public static String user(User u, String token) {
        Role r = u.getRole();
        StringBuilder sb = new StringBuilder("{");
        if (token != null) sb.append("\"token\":").append(str(token)).append(',');
        sb.append("\"username\":").append(str(u.getUsername()));
        sb.append(",\"name\":").append(str(u.getName()));
        sb.append(",\"role\":").append(str(r.name()));
        sb.append(",\"roleLabel\":").append(str(r.getLabel()));
        sb.append(",\"canCreate\":").append(r.canCreateGroups());
        sb.append(",\"canJoin\":").append(r.canJoinGroups());
        sb.append(",\"canRemoveOthers\":").append(r.canRemoveOthers());
        return sb.append('}').toString();
    }

    public static String activity(List<Activity> list) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < list.size(); i++) {
            Activity a = list.get(i);
            if (i > 0) sb.append(',');
            sb.append("{\"time\":").append(a.time)
              .append(",\"type\":").append(str(a.type))
              .append(",\"student\":").append(str(a.student))
              .append(",\"group\":").append(str(a.group))
              .append(",\"by\":").append(str(a.by)).append('}');
        }
        return sb.append(']').toString();
    }

    public static String error(String message) {
        return "{\"error\":" + str(message) + "}";
    }
}
