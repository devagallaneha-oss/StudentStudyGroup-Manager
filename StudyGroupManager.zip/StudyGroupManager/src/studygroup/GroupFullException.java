package studygroup;

/** Thrown when a student tries to join a group that has reached its maximum capacity. */
public class GroupFullException extends StudyGroupException {
    public GroupFullException(String groupName, int capacity) {
        super("\"" + groupName + "\" is full (" + capacity + "/" + capacity + " members). Join request rejected.", 409);
    }
}
