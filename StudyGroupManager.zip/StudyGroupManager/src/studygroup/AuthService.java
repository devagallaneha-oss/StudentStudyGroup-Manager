package studygroup;

import java.security.SecureRandom;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** User directory + login sessions (in memory). */
public class AuthService {
    private final Map<String, User> byUsername = new LinkedHashMap<>();
    private final Map<String, User> byName = new LinkedHashMap<>();
    private final Map<String, User> sessions = new ConcurrentHashMap<>();
    private final SecureRandom random = new SecureRandom();

    public synchronized User register(String username, String name, Role role, String password) {
        User u = new User(username, name, role, password);
        if (byUsername.containsKey(u.getUsername()))
            throw new StudyGroupException("Username \"" + u.getUsername() + "\" is already taken.", 409);
        if (byName.containsKey(u.getName().toLowerCase()))
            throw new StudyGroupException("A user named \"" + u.getName() + "\" already exists.", 409);
        byUsername.put(u.getUsername(), u);
        byName.put(u.getName().toLowerCase(), u);
        return u;
    }

    public synchronized User findByName(String name) {
        return name == null ? null : byName.get(name.trim().toLowerCase());
    }

    /** Role key (e.g. "CR") of the member with this display name, or "STUDENT" if unknown. */
    public synchronized String roleKeyOf(String name) {
        User u = findByName(name);
        return u == null ? Role.STUDENT.name() : u.getRole().name();
    }

    /** Returns a session token. Same error for unknown user and wrong password. */
    public String login(String username, String password) {
        User u;
        synchronized (this) {
            u = username == null ? null : byUsername.get(username.trim().toLowerCase());
        }
        if (u == null || !u.checkPassword(password))
            throw new StudyGroupException("Invalid username or password.", 401);
        byte[] b = new byte[24];
        random.nextBytes(b);
        StringBuilder sb = new StringBuilder();
        for (byte x : b) sb.append(String.format("%02x", x));
        String token = sb.toString();
        sessions.put(token, u);
        return token;
    }

    public void logout(String token) {
        if (token != null) sessions.remove(token);
    }

    /** The logged-in user for a token, or a 401 error. */
    public User require(String token) {
        User u = token == null ? null : sessions.get(token);
        if (u == null) throw new StudyGroupException("Please sign in first.", 401);
        return u;
    }
}
