package studygroup;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** A study group with a name, subject, description, capacity and a list of members. */
public class Group {
    private final int id;
    private final String name;
    private final String subject;
    private final String description;
    private final int capacity;
    private final String createdBy;
    private final List<String> members = new ArrayList<>();

    public Group(int id, String name, String subject, String description, int capacity, String createdBy) {
        this.id = id;
        this.name = name;
        this.subject = subject;
        this.description = description;
        this.capacity = capacity;
        this.createdBy = createdBy;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getSubject() { return subject; }
    public String getDescription() { return description; }
    public int getCapacity() { return capacity; }
    public String getCreatedBy() { return createdBy; }

    public List<String> getMembers() { return Collections.unmodifiableList(members); }
    public int getMemberCount() { return members.size(); }
    public int getSeatsLeft() { return capacity - members.size(); }
    public boolean isFull() { return members.size() >= capacity; }

    public boolean hasMember(String student) {
        for (String m : members) {
            if (m.equalsIgnoreCase(student)) return true;
        }
        return false;
    }

    /** Adds a member. Caller (GroupService) is responsible for validation. */
    void addMember(String student) { members.add(student); }

    boolean removeMember(String student) {
        return members.removeIf(m -> m.equalsIgnoreCase(student));
    }
}
