package studygroup;

/** One entry of the recent-activity feed shown on the dashboards. */
public final class Activity {
    public final long time;
    public final String type;     // create | join | leave | removed
    public final String student;  // who joined / left / was removed / created
    public final String group;
    public final String by;       // who performed it (differs from student for "removed")

    public Activity(String type, String student, String group, String by) {
        this.time = System.currentTimeMillis();
        this.type = type;
        this.student = student;
        this.group = group;
        this.by = by;
    }
}
