package studygroup;

/**
 * Demo accounts and sample groups so the dashboards are not empty on first start.
 *
 *   admin    / admin123     Admin
 *   drrao    / faculty123   Faculty (Dr. Rao)        profmehta / faculty123  Faculty (Prof. Mehta)
 *   asha     / cr123        Student CR               vikram    / cr123       Student CR
 *   ravi, meena, kiran, sana, divya, arjun, neha, rohit, isha, karan, tara, dev, lata, priya
 *            / student123   Student
 */
public final class SeedData {
    private SeedData() {}

    public static void load(AuthService auth, GroupService s) {
        User admin = auth.register("admin", "Admin", Role.ADMIN, "admin123");
        User rao = auth.register("drrao", "Dr. Rao", Role.FACULTY, "faculty123");
        auth.register("profmehta", "Prof. Mehta", Role.FACULTY, "faculty123");
        auth.register("asha", "Asha", Role.CR, "cr123");
        auth.register("vikram", "Vikram", Role.CR, "cr123");
        for (String n : new String[]{"Ravi", "Meena", "Kiran", "Sana", "Divya", "Arjun", "Neha", "Rohit",
                                     "Isha", "Karan", "Tara", "Dev", "Lata", "Priya"})
            auth.register(n.toLowerCase(), n, Role.STUDENT, "student123");

        Group g1 = s.createGroup(auth.findByName("Asha"), "Calculus Crew", "Mathematics", "Weekly problem solving for Calculus II.", 6);
        Group g2 = s.createGroup(rao, "Java Jedis", "Computer Science", "OOP, collections and exam prep in Java.", 5);
        Group g3 = s.createGroup(admin, "Quantum Questers", "Physics", "Working through quantum mechanics problem sets.", 4);
        Group g4 = s.createGroup(auth.findByName("Vikram"), "Data Structures Squad", "Computer Science", "Trees, graphs and complexity analysis.", 8);
        Group g5 = s.createGroup(rao, "Organic Chem Lab", "Chemistry", "Reaction mechanisms and lab report help.", 3);

        join(auth, s, g1, "Asha", "Ravi", "Meena", "Kiran", "Sana", "Vikram");  // full
        join(auth, s, g2, "Ravi", "Divya", "Arjun");
        join(auth, s, g3, "Neha", "Rohit", "Isha", "Karan");                    // full
        join(auth, s, g4, "Asha", "Tara");
        join(auth, s, g5, "Sana", "Dev", "Lata");                               // full
    }

    private static void join(AuthService auth, GroupService s, Group g, String... names) {
        for (String n : names) s.join(auth.findByName(n), g.getId());
    }
}
