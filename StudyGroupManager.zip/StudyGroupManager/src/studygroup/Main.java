package studygroup;

public class Main {
    public static void main(String[] args) throws Exception {
        int port = args.length > 0 ? Integer.parseInt(args[0]) : 8080;
        AuthService auth = new AuthService();
        GroupService service = new GroupService();
        SeedData.load(auth, service);
        new DashboardServer(service, auth, port).start();
        System.out.println("=======================================================");
        System.out.println(" Student Study Group Management - Dashboard is running");
        System.out.println(" Open in your browser:  http://localhost:" + port);
        System.out.println(" Demo logins:  admin/admin123   drrao/faculty123");
        System.out.println("               asha/cr123       ravi/student123");
        System.out.println(" Press Ctrl+C to stop.");
        System.out.println("=======================================================");
    }
}
