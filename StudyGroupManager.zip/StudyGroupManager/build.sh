#!/usr/bin/env bash
# Compiles the project into ./out (requires JDK 11+)
set -e
cd "$(dirname "$0")"
rm -rf out && mkdir -p out/web
javac -d out src/studygroup/*.java test/studygroup/*.java
cp src/web/index.html out/web/index.html
echo "Build OK -> ./out"
